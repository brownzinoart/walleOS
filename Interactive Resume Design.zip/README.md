
  # Interactive Resume Design

  This is a code bundle for Interactive Resume Design. The original project is available at https://www.figma.com/design/dQ6maGTy0VHVraI1F1V82s/Interactive-Resume-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  